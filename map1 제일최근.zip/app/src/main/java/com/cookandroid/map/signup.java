package com.cookandroid.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class signup extends AppCompatActivity {

    // UI Components
    private EditText etSignupId, etSignupPassword, etSignupPasswordConfirm;
    private Button btnSignup, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        // Initialize UI components
        etSignupId = findViewById(R.id.signup_id);
        etSignupPassword = findViewById(R.id.signup_password);
        etSignupPasswordConfirm = findViewById(R.id.signup_password_confirm);
        btnSignup = findViewById(R.id.signup_button);
        btnBack = findViewById(R.id.btnBack);

        // 뒤로가기 버튼 클릭 시 로그인 화면으로 이동
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signup.this, MainActivity.class);  // LoginActivity로 이동
                startActivity(intent);
                finish();  // 현재 Activity 종료
            }
        });

        // 회원가입 버튼 클릭 시
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String signupId = etSignupId.getText().toString().trim();
                String signupPassword = etSignupPassword.getText().toString().trim();
                String signupPasswordConfirm = etSignupPasswordConfirm.getText().toString().trim();

                // Check if all fields are filled
                if (signupId.isEmpty() || signupPassword.isEmpty() || signupPasswordConfirm.isEmpty()) {
                    Toast.makeText(signup.this, "모든 필드를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else if (!signupPassword.equals(signupPasswordConfirm)) {
                    // Check if passwords match
                    Toast.makeText(signup.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    // Proceed with signup logic (e.g., save to database)
                    // For now, just show a success message
                    Toast.makeText(signup.this, "회원가입 성공!", Toast.LENGTH_SHORT).show();

                    // Optionally, go back to the login page after successful signup
                    finish();  // Closes SignupActivity and returns to the previous activity (MainActivity)
                }
            }
        });
    }
}

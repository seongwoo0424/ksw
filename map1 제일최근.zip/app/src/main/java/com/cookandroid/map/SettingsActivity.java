package com.cookandroid.map;

public class SettingsActivity {
}

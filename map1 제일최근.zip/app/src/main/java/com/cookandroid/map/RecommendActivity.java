package com.cookandroid.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import android.widget.Toast;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.core.view.GravityCompat;
import java.util.ArrayList;

import com.google.android.material.navigation.NavigationView;

public class RecommendActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private EditText etPlaceName, etPlaceDescription;
    private Button btnSave, btnShare;
    private ArrayList<Place> placeList;
    private ImageButton menuButton;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend_place);

        etPlaceName = findViewById(R.id.place_name);
        etPlaceDescription = findViewById(R.id.place_description);
        btnSave = findViewById(R.id.btn_save);
        btnShare = findViewById(R.id.btn_share);
        drawerLayout = findViewById(R.id.drawer_layout); // drawerLayout 초기화
        navigationView = findViewById(R.id.navigation_view);
        menuButton = findViewById(R.id.menu_button);

        // 햄버거 버튼 클릭 이벤트
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        // 네비게이션 메뉴 아이템 선택 리스너
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId(); // 선택된 메뉴의 ID 가져오기
                if(id == R.id.nav_home){
                    openHome();
                } else if (id == R.id.nav_settings) {
                    openSettings();
                } else if (id == R.id.nav_my_page) {
                    openMyPage();
                } else if (id == R.id.nav_recommend) {
                    // 현재 화면이므로 아무 동작 없음
                } else if (id == R.id.nav_favorites) {
                    openFavorites();
                }

                // 드로어 닫기
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        // 추천 장소 리스트 초기화
        placeList = new ArrayList<>();

        // 저장 버튼 클릭 이벤트
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etPlaceName.getText().toString();
                String description = etPlaceDescription.getText().toString();

                if (!name.isEmpty() && !description.isEmpty()) {
                    // 장소 데이터 추가
                    Place place = new Place(name, description);
                    placeList.add(place);

                    Toast.makeText(RecommendActivity.this, "장소가 저장되었습니다.", Toast.LENGTH_SHORT).show();

                    // 입력 필드 초기화
                    etPlaceName.setText("");
                    etPlaceDescription.setText("");
                } else {
                    Toast.makeText(RecommendActivity.this, "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (placeList.isEmpty()) {
                    Toast.makeText(RecommendActivity.this, "공유할 장소가 없습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 공유할 내용 작성
                StringBuilder shareContent = new StringBuilder("추천 장소 목록:\n");
                for (Place place : placeList) {
                    shareContent.append("- ").append(place.getName()).append(": ").append(place.getDescription()).append("\n");
                }

                // 공유 인텐트 생성
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "추천 장소");
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent.toString());

                startActivity(Intent.createChooser(shareIntent, "공유하기"));
            }
        });

    }
    private  void openHome(){
        Intent intent = new Intent(RecommendActivity.this, home.class);
        startActivity(intent);
    }
    private void openSettings() {
        Intent intent = new Intent(RecommendActivity.this, SettingsActivity.class);
        startActivity(intent);
    }

    private void openMyPage() {
        Intent intent = new Intent(RecommendActivity.this, MyPageActivity.class);
        startActivity(intent);
    }

    private void openFavorites() {
        Intent intent = new Intent(RecommendActivity.this, FavoritesActivity.class);
        startActivity(intent);
    }
}



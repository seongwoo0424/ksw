package com.cookandroid.map;

public class FavoritesActivity {
}

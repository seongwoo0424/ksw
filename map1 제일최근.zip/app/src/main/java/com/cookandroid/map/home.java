package com.cookandroid.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class home extends AppCompatActivity {

    // UI Components
    private EditText etSearch;
    private ImageButton menuButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // activity_home.xml 설정

        // Initialize UI components
        etSearch = findViewById(R.id.search_bar); // 검색창
        menuButton = findViewById(R.id.menu_button); // 메뉴 버튼
        drawerLayout = findViewById(R.id.drawer_layout); // 드로어 레이아웃
        navigationView = findViewById(R.id.navigation_view); // 네비게이션 뷰

        // 메뉴 버튼 클릭 리스너
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        // 네비게이션 메뉴 아이템 선택 리스너
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId(); // 선택된 메뉴의 ID 가져오기

                if (id == R.id.nav_settings) {
                    openSettings();
                } else if (id == R.id.nav_my_page) {
                    openMyPage();
                } else if (id == R.id.nav_recommend) {
                    openRecommendPlace();
                } else if (id == R.id.nav_favorites) {
                    openFavorites();
                }

                // 드로어 닫기
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    // "설정" 화면으로 이동
    private void openSettings() {
        Intent intent = new Intent(home.this, SettingsActivity.class);
        startActivity(intent);
    }

    // "마이페이지" 화면으로 이동
    private void openMyPage() {
        Intent intent = new Intent(home.this, MyPageActivity.class);
        startActivity(intent);
    }

    // "추천 장소 등록 및 공유" 화면으로 이동
    private void openRecommendPlace() {
        Intent intent = new Intent(home.this, RecommendActivity.class);
        startActivity(intent);
    }

    // "즐겨찾기" 화면으로 이동
    private void openFavorites() {
        Intent intent = new Intent(home.this, FavoritesActivity.class);
        startActivity(intent);
    }
}
package com.cookandroid.map;

public class MyPageActivity {
}
